plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "tw.nero.twitchautocollector"
    compileSdk = 35

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        applicationId = "tw.nero.twitchautocollector"
        minSdk = 30
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"
    }
}


dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}

kotlin {
    jvmToolchain(17)
}
