package tw.nero.twitchautocollector

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var count: TextView
    private lateinit var history: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notify.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10
            )
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "Twitch Auto Collector"
            textSize = 24f
        }
        status = TextView(this).apply { textSize = 16f }
        count = TextView(this).apply { textSize = 20f }
        history = TextView(this).apply { textSize = 14f }

        val accessibility = Button(this).apply {
            text = "開啟 Android 無障礙設定"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val start = Button(this).apply {
            text = "開始監控"
            setOnClickListener {
                StatsStore.setEnabled(this@MainActivity, true)
                refresh()
            }
        }
        val stop = Button(this).apply {
            text = "停止監控"
            setOnClickListener {
                StatsStore.setEnabled(this@MainActivity, false)
                refresh()
            }
        }
        val refresh = Button(this).apply {
            text = "重新整理統計"
            setOnClickListener { refresh() }
        }

        listOf(title, status, count, accessibility, start, stop, refresh, history).forEach {
            layout.addView(it, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 18 })
        }
        setContentView(layout)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refresh()
    }

    private fun refresh() {
        status.text = if (StatsStore.isEnabled(this)) "監控設定：已開啟" else "監控設定：已停止"
        count.text = "今日點擊：${StatsStore.todayTaps(this)} 次；寶箱消失：${StatsStore.todayCount(this)} 次"
        history.text = buildString {
            append("最近 7 日紀錄\n")
            StatsStore.history(this@MainActivity).forEach { (date, value) ->
                append("$date：$value 次\n")
            }
            append("\n注意：寶箱消失不代表 Twitch 伺服器已確認入帳。Android 11 以上、Twitch 前景及螢幕亮起時監控。")
        }
    }
}
