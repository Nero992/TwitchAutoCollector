package tw.nero.twitchautocollector

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.Executors
import kotlin.math.abs

/** Android 11+ accessibility screenshots: no separate MediaProjection permission needed. */
class TwitchAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var inFlight = false
    private var lastTap = 0L
    private var pendingConfirmation = false
    private var previousWasChest = false
    private val twitchPackage = "tv.twitch.android.app"
    private lateinit var template: Bitmap

    private val loop = object : Runnable {
        override fun run() {
            if (StatsStore.isEnabled(this@TwitchAccessibilityService) &&
                rootInActiveWindow?.packageName?.toString() == twitchPackage && !inFlight &&
                Build.VERSION.SDK_INT >= 30) capture()
            handler.postDelayed(this, 2200)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        template = assets.open("chest_template.png").use { Bitmap.createScaledBitmap(android.graphics.BitmapFactory.decodeStream(it), 40, 40, false) }
        handler.post(loop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    private fun capture() {
        if (Build.VERSION.SDK_INT < 30) return
        inFlight = true
        takeScreenshot(Display.DEFAULT_DISPLAY, executor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val bmp = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                if (bmp == null) { result.hardwareBuffer.close(); handler.post { inFlight = false }; return }
                val copy = bmp.copy(Bitmap.Config.ARGB_8888, false)
                result.hardwareBuffer.close()
                val target = try { locateChest(copy) } finally { copy.recycle() }
                handler.post {
                    inFlight = false
                    if (!StatsStore.isEnabled(this@TwitchAccessibilityService) ||
                        rootInActiveWindow?.packageName?.toString() != twitchPackage) return@post
                    if (pendingConfirmation) {
                        // A disappearance suggests the button was acted on, not server-side credit confirmation.
                        if (target == null) StatsStore.recordClaim(this@TwitchAccessibilityService)
                        pendingConfirmation = false
                    }
                    val now = SystemClock.elapsedRealtime()
                    if (target != null && now - lastTap > 60_000L) {
                        lastTap = now
                        tap(target.first.toFloat(), target.second.toFloat())
                    }
                }
            }
            override fun onFailure(errorCode: Int) { handler.post { inFlight = false } }
        })
    }

    /** Detects bright green rounded rectangle and verifies dark chest strokes against reference. */
    private fun locateChest(b: Bitmap): Pair<Int, Int>? {
        val w=b.width; val h=b.height
        // Based on Twitch portrait UI: bottom-left, never scan video/reward tiles.
        val xEnd=(w*.29).toInt(); val yStart=(h*.77).toInt(); val yEnd=(h*.985).toInt()
        val step=(w/240).coerceAtLeast(2)
        var left=w; var top=h; var right=0; var bottom=0; var n=0
        for(y in yStart until yEnd step step) for(x in 0 until xEnd step step) {
            val c=b.getPixel(x,y); val r=Color.red(c); val g=Color.green(c); val bl=Color.blue(c)
            if (g>155 && g>r*1.7 && bl>70 && bl>r*1.5 && r<110) {
                n++; if(x<left)left=x; if(x>right)right=x; if(y<top)top=y; if(y>bottom)bottom=y
            }
        }
        if(n<80 || right-left < w*.11 || bottom-top < h*.025 || right-left > w*.29) return null
        // The chest icon is centered inside the green region; sample an inset square.
        val cx=(left+right)/2; val cy=(top+bottom)/2
        val side=((bottom-top)*.48).toInt().coerceAtLeast(18)
        val score=matchDarkShape(b,cx,cy,side)
        return if(score >= .73) Pair(cx,cy) else null
    }

    private fun matchDarkShape(b: Bitmap, cx:Int, cy:Int, side:Int): Double {
        var agree=0; var total=0
        for(j in 3 until 37 step 2) for(i in 3 until 37 step 2) {
            val x=cx-side/2+i*side/40; val y=cy-side/2+j*side/40
            if(x !in 0 until b.width || y !in 0 until b.height) continue
            val a=b.getPixel(x,y); val t=template.getPixel(i,j)
            val darkA=Color.red(a)<100 && Color.green(a)<140 && Color.blue(a)<125
            val darkT=Color.red(t)<110 && Color.green(t)<150 && Color.blue(t)<130
            if(darkA==darkT) agree++
            total++
        }
        return if(total==0) 0.0 else agree.toDouble()/total
    }

    private fun tap(x:Float,y:Float) {
        val path=Path().apply { moveTo(x,y) }
        val gesture=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,80)).build()
        dispatchGesture(gesture, object: GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                pendingConfirmation=true
                val count=StatsStore.recordTap(this@TwitchAccessibilityService)
                Notify.claimed(this@TwitchAccessibilityService,count)
            }
        },handler)
    }

    override fun onInterrupt() = Unit
    override fun onDestroy() { handler.removeCallbacks(loop); executor.shutdownNow(); super.onDestroy() }
}
