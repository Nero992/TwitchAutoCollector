# Twitch Auto Collector (Android)

這是個人測試用 Android Studio/Kotlin 專案雛形，目標是在 Twitch 官方 Android App 的可見畫面中辨識 Bonus/Claim 按鈕。

## 目前功能
- 啟用/停止監控
- 監聽 Twitch 官方 App 的無障礙 UI 事件
- 比對明確的領取按鈕文字
- 嘗試點擊該按鈕
- 本機每日點擊次數紀錄
- Android 通知

## 建置
1. 使用 Android Studio 開啟此資料夾。
2. 等待 Gradle Sync。
3. 使用 Android SDK 35 建置並安裝到自己的 Android 手機。
4. 開啟 App，按「開啟 Android 無障礙設定」。
5. 在已下載的服務中啟用「Twitch 領取提示助手」。
6. 回到 App，按「開始監控」，再切換到 Twitch 官方 App。

## 重要限制
- 無障礙服務只能辨識 Twitch 實際暴露給 Android Accessibility 的 UI 文字/節點；若 Twitch 把按鈕畫成不可讀的自訂畫面，這個版本就無法辨識。
- 只在 Twitch 畫面可見且系統送出無障礙事件時工作；不會在手機鎖定、Twitch 未顯示或畫面不可讀時持續掃描。
- 文字標籤會因 Twitch 版本、語言和 A/B 測試而變化，可能需要依實機事件調整。
- 「領取成功統計」目前記錄的是 Android 回報點擊動作成功，不是 Twitch 後端入帳確認；官方沒有提供一般觀眾的 Bonus 領取確認 API。
- 請勿用於違反 Twitch 條款、規避限制或影響其他使用者的行為。Android 無障礙權限很強，請只在自己信任的裝置上啟用。
- 側載 APK 不代表符合 Google Play 無障礙服務政策；本專案以個人測試為目的。
