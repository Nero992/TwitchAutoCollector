package tw.nero.twitchautocollector

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock
import java.util.Locale

class TwitchAccessibilityService : AccessibilityService() {
    private var lastActionAt = 0L
    private var lastSignature = ""

    // Twitch 官方 Android App 的套件名稱
    private val twitchPackage = "tv.twitch.android.app"

    // 不同語言/版本的文字可能不同；只比對明確的領取字樣。
    private val claimLabels = listOf(
        "claim bonus", "claim your bonus", "claim reward",
        "領取獎勵", "領取加成", "領取點數", "領取", "寶箱", "獎勵寶箱", "bonus", "channel points"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !StatsStore.isEnabled(this)) return
        if (rootInActiveWindow == null) return
        if (event.packageName?.toString() != twitchPackage) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastActionAt < 2500) return

        val root = rootInActiveWindow ?: return
        val candidate = findClaimNode(root) ?: return
        val signature = "${candidate.text}|${candidate.viewIdResourceName}"
        if (signature == lastSignature && now - lastActionAt < 8000) return

        val clickable = findClickableAncestor(candidate) ?: return
        if (!clickable.isVisibleToUser || !clickable.isEnabled) return

        // 僅對可見、可點擊且文字符合領取標籤的節點執行點擊。
        val clicked = clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        lastActionAt = now
        lastSignature = signature

        if (clicked) {
            val count = StatsStore.recordClaim(this)
            Notify.claimed(this, count)
        }
    }

    private fun findClaimNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val text = (node.text?.toString() ?: node.contentDescription?.toString() ?: "")
            .lowercase(Locale.ROOT).trim()

        if (claimLabels.any { label -> text == label || text.contains(label) }) return node

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findClaimNode(child)
            if (found != null) return found
        }
        return null
    }

    private fun findClickableAncestor(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var current: AccessibilityNodeInfo? = node
        repeat(6) {
            if (current == null) return null
            if (current!!.isClickable) return current
            current = current!!.parent
        }
        return null
    }

    override fun onInterrupt() = Unit
}
