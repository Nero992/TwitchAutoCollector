# TwitchAutoCollector v1.2 (實驗版)

使用 Android 11+ AccessibilityService.takeScreenshot 擷取 Twitch 前景畫面，檢查左下角綠色區塊與黑色寶箱圖示，然後用無障礙手勢點擊。

使用：安裝 APK → 授權無障礙 → 開啟監控 → 切換 Twitch 直播。保持螢幕亮起。

限制：此版本使用提供的截圖作為圖案範本；因縮放、介面版本不同可能漏判或誤判。僅計數點擊及寶箱消失，**無法驗證 Twitch 伺服器點數入帳**。不掃描其他應用程式、不上傳畫面、不需網路權限。

GitHub Actions：把 ZIP 放在儲存庫根目錄，修改 workflow 的 unzip 檔名為 TwitchAutoCollector_v1_2_source.zip。
