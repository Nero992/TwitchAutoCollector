package tw.nero.twitchautocollector

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object StatsStore {
    private const val PREFS = "collector_stats"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_DAILY = "daily_"

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun recordClaim(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = KEY_DAILY + todayKey()
        val newCount = prefs.getInt(key, 0) + 1
        prefs.edit().putInt(key, newCount).apply()
        return newCount
    }

    fun recordTap(context: Context): Int {
        val prefs=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
        val key="tap_"+todayKey()
        val n=prefs.getInt(key,0)+1
        prefs.edit().putInt(key,n).apply()
        return n
    }

    fun todayTaps(context: Context): Int = context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
        .getInt("tap_"+todayKey(),0)

    fun todayCount(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_DAILY + todayKey(), 0)

    fun history(context: Context, days: Int = 7): List<Pair<String, Int>> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return (0 until days).map { offset ->
            val date = java.util.Calendar.getInstance().apply {
                add(java.util.Calendar.DAY_OF_YEAR, -offset)
            }.time
            val key = sdf.format(date)
            key to prefs.getInt(KEY_DAILY + key, 0)
        }
    }
}
